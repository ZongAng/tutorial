//
//  ViewController.m
//  核心动画(ZongAng)
//
//  Created by mac on 16/7/27.
//  Copyright © 2016年 纵昂. All rights reserved.
//

#import "ViewController.h"

#define kScreenWidth [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.height

@interface ViewController ()
{
//    用于动画的图层
    CALayer * _layer;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    UIImageView * zimage =[[UIImageView alloc] init];
    zimage.frame=self.view.frame;
    zimage.image=[UIImage imageNamed:@"45b890a6d09c26c5bbce905338a2830e.jpg"];
    [self.view addSubview:zimage];

    _layer = [CALayer layer];
    _layer.frame = self.view.frame;
    _layer.backgroundColor = [UIColor orangeColor].CGColor;
    UIImage * image =[UIImage imageNamed:@"45b890a6d09c26c5bbce905338a2830e.jpg"];
    _layer.contents =(id)image.CGImage;
    _layer.borderWidth = 5;
    _layer.shadowColor = [UIColor greenColor].CGColor;
    _layer.shadowRadius = 10;
    _layer.shadowOffset = CGSizeMake(3, 3);
    _layer.cornerRadius = 10;
    [self.view.layer addSublayer:_layer];
    
    NSArray * titleArray =@[@"上翻",@"下翻",@"左转",@"右转",@"淡化",@"推挤",@"揭开",@"覆盖",@"立方体",@"吸收",@"翻转",@"波纹",@"翻页",@"反翻页",@"镜头开",@"镜头关"];
    
    float speedX = (kScreenWidth - 3 * 72) / 4;
    for (int i =0 ; i<16; i++) {
        UIButton * button =[UIButton buttonWithType:UIButtonTypeCustom];
        button.frame =CGRectMake(speedX + i % 3 * (speedX + 50),50 + speedX + i / 3 * (speedX + 30) , 80, 72);
//        button.backgroundColor =[UIColor yellowColor];
        [button setTitle:[titleArray objectAtIndex:i] forState:UIControlStateNormal];
        button.tag =i+1;
        [button setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        [button addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:button];
        
  }
    
}
-(void)buttonClick:(UIButton *)sender{
    switch (sender.tag) {
        case 1:
        {
            NSLog(@"你点击了上翻");
            
            [self topZongAng];
            
        }
            break;
        case 2:
        {
            NSLog(@"你点击了下翻");
            
            [self lowFan];
        }
            break;
        case 3:
        {
            NSLog(@"你点击了左转");
            
            [self leftZhuan];
        }
            break;
        case 4:
        {
            NSLog(@"你点击了右转");
            
            [self rightzhuan];
        }
            break;
        case 5:
        {
            NSLog(@"你点击了淡化");
            
            [self desalination];
        }
            break;
        case 6:
        {
            NSLog(@"你点击了推挤");
            
            [self push];
        }
            break;
        case 7:
        {
            NSLog(@"你点击了揭开");
            
            [self jiekai];
        }
            break;
        case 8:
        {
            NSLog(@"你点击了覆盖");
            
            [self overLap];
        }
            break;
        case 9:
        {
            NSLog(@"你点击了立方体");
        }
            break;
        case 10:
        {
            NSLog(@"你点击了吸收");
            
            [self xiShou];
        }
            break;
        case 11:
        {
            NSLog(@"你点击了翻转");
            
            
        }
            break;
        case 12:
        {
            NSLog(@"你点击了波纹");
            
            [self boWen];
        }
            break;
        case 13:
        {
            NSLog(@"你点击了翻页");
            
            [self fanYe];
        }
            break;
        case 14:
        {
            NSLog(@"你点击了反翻页");
            
            [self fanFanYe];
        }
            break;
        case 15:
        {
            NSLog(@"你点击了镜头开");
            
            [self jingTouKai];
        }
            break;
        case 16:
        {
            NSLog(@"你点击了镜头关");
            
            [self jiingMenGuan];
        }
            break;
        default:
            break;
    }
}
/**
 *  上翻动画
 */
-(void)topZongAng{
    
   CATransition *transitionAnimation = [CATransition animation];
    transitionAnimation.duration = 0.5;
//   动画类型
    transitionAnimation.type =@"cube";
    
    //    动画子类型
    NSArray *subTypeArray = @[kCATransitionFromTop];
    transitionAnimation.subtype = subTypeArray[arc4random()%(subTypeArray.count)];

    [_layer addAnimation:transitionAnimation forKey:@"transition_animation"];
    
   
    
}
/**
 *  下翻
 */
-(void)lowFan{
    
    CATransition *transitionAnimation = [CATransition animation];
    transitionAnimation.duration = 0.5;
    //   动画类型
    transitionAnimation.type =@"cube";
    
    //    动画子类型
    NSArray *subTypeArray = @[kCATransitionFromBottom];
    transitionAnimation.subtype = subTypeArray[arc4random()%(subTypeArray.count)];
    
    [_layer addAnimation:transitionAnimation forKey:@"transition_animation"];
 
    
}
/**
 *  左转
 */
-(void)leftZhuan{
   
    CATransition *transitionAnimation = [CATransition animation];
    transitionAnimation.duration = 0.5;
    //   动画类型
    transitionAnimation.type =@"cube";
    
    //    动画子类型
    NSArray *subTypeArray = @[kCATransitionFromLeft];
    transitionAnimation.subtype = subTypeArray[arc4random()%(subTypeArray.count)];
    
    [_layer addAnimation:transitionAnimation forKey:@"transition_animation"];
    
}
/**
 *  右转
 */
-(void)rightzhuan{
    CATransition *transitionAnimation = [CATransition animation];
    transitionAnimation.duration = 0.5;
    //   动画类型
    transitionAnimation.type =@"cube";
    
    //    动画子类型
    NSArray *subTypeArray = @[kCATransitionFromRight];
    transitionAnimation.subtype = subTypeArray[arc4random()%(subTypeArray.count)];
    
    [_layer addAnimation:transitionAnimation forKey:@"transition_animation"];
}
/**
 *  淡化
 */
-(void)desalination{
    
    CATransition *transitionAnimation = [CATransition animation];
    transitionAnimation.duration = 0.1;
    //   动画类型
    transitionAnimation.type =@"fade";//交叉淡化过渡(不支持过渡方向)
    
    //    动画子类型
    NSArray *subTypeArray = @[kCATransitionFade];
    transitionAnimation.subtype = subTypeArray[arc4random()%(subTypeArray.count)];
    
    [_layer addAnimation:transitionAnimation forKey:@"transition_animation"];
    
}

/**
 *  推挤
 */
-(void)push{
    //    旋转
    CABasicAnimation *rotationAnimation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
    rotationAnimation.duration = 1.5;
    rotationAnimation.toValue = @(M_PI);
    rotationAnimation.autoreverses = YES;
    [_layer addAnimation:rotationAnimation forKey:@"rotation_animation"];

    
}

//揭开
-(void)jiekai{
//    缩放
    CABasicAnimation *scaleAnimation = [CABasicAnimation animationWithKeyPath:@"transform.scale"];
    scaleAnimation.duration = 1.5;
    scaleAnimation.toValue = @(2.0);
    scaleAnimation.autoreverses = YES;
    [_layer addAnimation:scaleAnimation forKey:@"scale_animation"];

}

/**
 *  覆盖
 */
-(void)overLap{
    
    CATransition *transitionAnimation = [CATransition animation];
    transitionAnimation.duration = 0.1;
    //   动画类型
    transitionAnimation.type =@"moveal";
    
    //    动画子类型
    NSArray *subTypeArray = @[kCATransitionMoveIn];
    transitionAnimation.subtype = subTypeArray[arc4random()%(subTypeArray.count)];
    
    [_layer addAnimation:transitionAnimation forKey:@"transition_animation"];
    
}
/**
 *  翻页
 */
-(void)fanYe{
    
    ViewController *boundarVC =[[ViewController alloc]init];
    [UIApplication sharedApplication].delegate.window.rootViewController =boundarVC;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:2];
    [UIView setAnimationTransition:UIViewAnimationTransitionCurlUp forView:[UIApplication sharedApplication].keyWindow cache:YES];
    [UIView commitAnimations];
    
}
/**
 *  反翻页
 */
-(void)fanFanYe{
    ViewController *boundarVC =[[ViewController alloc]init];
    [UIApplication sharedApplication].delegate.window.rootViewController =boundarVC;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:2];
    [UIView setAnimationTransition:UIViewAnimationTransitionCurlDown forView:[UIApplication sharedApplication].keyWindow cache:YES];
    [UIView commitAnimations];
}
/**
 *  波纹
 */
-(void)boWen{
    CATransition *transitionAnimation = [CATransition animation];
    transitionAnimation.duration = 0.5;
    //   动画类型
    transitionAnimation.type =@"rippleEffect";
    
    //    动画子类型
    NSArray *subTypeArray = @[kCATransitionMoveIn];
    transitionAnimation.subtype = subTypeArray[arc4random()%(subTypeArray.count)];
    
    [_layer addAnimation:transitionAnimation forKey:@"transition_animation"];
 
}
/**
 *  吸收
 */
-(void)xiShou{
    CATransition *transitionAnimation = [CATransition animation];
    transitionAnimation.duration = 0.5;
    //   动画类型
    transitionAnimation.type =@"suckEffect";
    
    //    动画子类型
    NSArray *subTypeArray = @[kCATransitionMoveIn];
    transitionAnimation.subtype = subTypeArray[arc4random()%(subTypeArray.count)];
    
    [_layer addAnimation:transitionAnimation forKey:@"transition_animation"];
}
/**
 *  镜头开
 */
-(void)jingTouKai{
    
    CATransition *transitionAnimation = [CATransition animation];
    transitionAnimation.duration = 0.5;
    //   动画类型
    transitionAnimation.type =@"cameraIrisHollowOpen";
    
    //    动画子类型
    NSArray *subTypeArray = @[kCATransitionMoveIn];
    transitionAnimation.subtype = subTypeArray[arc4random()%(subTypeArray.count)];
    
    [_layer addAnimation:transitionAnimation forKey:@"transition_animation"];

}
/**
 *  镜头关
 */
-(void)jiingMenGuan{
   
    CATransition *transitionAnimation = [CATransition animation];
    transitionAnimation.duration = 0.5;
    //   动画类型
    transitionAnimation.type =@"cameraIrisHollowClose";
    //    动画子类型
    NSArray *subTypeArray = @[kCATransitionFromBottom];
    transitionAnimation.subtype = subTypeArray[arc4random()%(subTypeArray.count)];
    
    [_layer addAnimation:transitionAnimation forKey:@"transition_animation"];
}



@end
