//
//  ViewController.m
//  NSURLConnection(ZongAng1)
//
//  Created by mac on 16/7/28.
//  Copyright © 2016年 纵昂. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<NSURLConnectionDelegate,NSURLConnectionDataDelegate>
{
    NSMutableData *_buffer;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    //NSURLConnection常用到的类
    //1.NSURL:请求路径  --- 统一资源定位符
    //2.NSURLRequest:请求对象 ---- 封装了请求的全部数据：NSURL对象，请求方式，请求体
    //3.NSMutableURLRequest:   NSURLRequest的子类
    //4.NSURLConnection:发送数据，建立服务器和客户端的联系。将NSURLRequest对象中的数据发送给我们的服务器，同时接收服务器的响应（数据）
    /**
     发送请求需要三步：
     1.设置请求路径
     2.创建请求对象
     3.发送请求，建立连接
     */
    
    //1.设置请求路径
    NSURL *url = [NSURL URLWithString:@"https://www.hao123.com"];
    //2.创建请求对象
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    //3.发送请求，建立连接
    //3.1同步请求：
    //    [self syncRequest:request];
    
    //3.2异步发送请求
    //以block作为回调
    //异步请求：不需要等待服务器相应，会开辟一个分线程请求数据，当前线程继续向下执行，接收到响应数据后，分线程回调block、delegate来获得数据（回到主线程刷新UI）
    //    [self asyncBLockRequest:request];
    
    //3.3
    [NSURLConnection connectionWithRequest:request delegate:self];
    
    
}

#pragma mark - NSURLConnectionDelegate,NSURLConnectionDataDelegate
//当我们接收到响应时调用
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    NSLog(@"------------------111111");
    _buffer = [[NSMutableData alloc] init];
}
//当收到服务器的响应数据时调用
- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
    [_buffer appendData:data];
}
//当响应数据全部接收完时调用
- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
    NSString *str = [[NSString alloc] initWithData:_buffer encoding:NSUTF8StringEncoding];
    [self showWebView:str];
}


- (void)asyncBLockRequest:(NSURLRequest *)request {
    NSOperationQueue *queue = [[NSOperationQueue alloc] init];
    [NSURLConnection sendAsynchronousRequest:request queue:queue completionHandler:^(NSURLResponse * _Nullable response, NSData * _Nullable data, NSError * _Nullable connectionError) {
        NSString *str = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        
        [self performSelectorOnMainThread:@selector(showWebView:) withObject:str waitUntilDone:NO];
        NSLog(@"2.---------------------");
    }];
    
    NSLog(@"1.---------------------");
}

- (void)showWebView:(NSString *)str {
    UIWebView *web = [[UIWebView alloc] initWithFrame:self.view.bounds];
    web.scalesPageToFit = YES;
    [web loadHTMLString:str baseURL:nil];
    [self.view addSubview:web];
}

- (void)syncRequest:(NSURLRequest *)request {
    NSData *data = [NSURLConnection sendSynchronousRequest:request returningResponse:nil error:nil];
    NSString *str = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    
    //同步请求在数据返回之前，我们的线程会一直卡在发送请求代码处，之后的代码不会执行
    [self showWebView:str];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
